#include <iostream>

using namespace std;

int main()
{
    int total;
    total = 12;
    cout << total << endl;

    total = total + 5;
    cout << total << endl;

    return 0;
}
