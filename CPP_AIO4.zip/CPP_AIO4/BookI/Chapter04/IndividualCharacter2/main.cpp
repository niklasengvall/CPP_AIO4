#include <iostream>

using namespace std;

int main()
{
    string mystring;
    mystring = "abcdef";
    char mychar = mystring[2];
    cout << mychar << endl;
}
