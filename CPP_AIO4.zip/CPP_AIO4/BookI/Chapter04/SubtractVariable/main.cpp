#include <iostream>

using namespace std;

int main()
{
  int final;
  int time;

  final = 28;
  time = 18;

  cout << final - time << endl;
  return 0;
}
