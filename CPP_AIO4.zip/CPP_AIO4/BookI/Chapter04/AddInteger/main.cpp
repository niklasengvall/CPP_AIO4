#include <iostream>

using namespace std;

int main()
{
    int start;
    int time;
    start = 37;
    time = 22;
    cout << start + time  << endl;
    return 0;
}
