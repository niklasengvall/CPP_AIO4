#include <iostream>

using namespace std;

int main()
{
    int first, second;
    cout << "Dividing 28 by 14." << endl;
    first = 28;
    second = 14;
    cout << "Quotient  " << first / second << endl;
    cout << "Remainder " << first % second << endl;

    cout << "Dividing 32 by 6." << endl;
    first = 32;
    second = 6;
    cout << "Quotient  " << first / second << endl;
    cout << "Remainder " << first % second << endl;
    return 0;
}
