#include <iostream>

using namespace std;

int main()
{
    int start;
    int time;
    int total;

    start = 37;
    time = 22;
    total =  start + time;

    cout << total << endl;
    return 0;
}
