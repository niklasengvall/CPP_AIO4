#include <iostream>

using namespace std;

int main()
{
  int NumberOfPotholes = 532587;
  cout << &NumberOfPotholes << endl;
  return 0;
}
