#include <iostream>

using namespace std;

int main()
{
    cout << "Hello from Copied Files!" << endl;
    return 0;
}
