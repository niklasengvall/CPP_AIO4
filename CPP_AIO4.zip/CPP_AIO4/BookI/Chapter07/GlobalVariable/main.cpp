#include <iostream>
#include "sharealike.h"

using namespace std;

int main()
{
  DoubleCheeseburgers = 20;
  EatAtJoes();
  return 0;
}
