void BigDog(int KibblesCount);

int main() {
  BigDog(3);
  return 0;
}
