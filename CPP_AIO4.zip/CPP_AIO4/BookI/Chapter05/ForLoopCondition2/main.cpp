#include <iostream>

using namespace std;

int main()
{
  string hello = "Hello";
  int values[] = {1, 2, 3, 4, 5, 0};

  for (int i = 0; auto c = values[i]; i++)
  {
    cout << c << endl;
  }

  return 0;
}
