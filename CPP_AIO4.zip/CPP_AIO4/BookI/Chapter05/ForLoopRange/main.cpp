#include <iostream>

using namespace std;

int main()
{
  int range[] = {1, 2, 3, 4, 5};

  for (int i : range)
  {
    cout << i << endl;
  }

  return 0;
}
