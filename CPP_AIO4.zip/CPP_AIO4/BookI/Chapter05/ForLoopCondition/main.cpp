#include <iostream>

using namespace std;

int main()
{
  string hello = "Hello";
  for (int i = 0; char c = hello[i]; i++)
  {
    cout << c << endl;
  }

  return 0;
}
