#include <iostream>

using namespace std;

int main()
{
    int i = 15;
    do
    {
        cout << i << endl;
        i++;
    }
    while (i <= 5);
    cout << "All Finished!" << endl;
    return 0;
}
