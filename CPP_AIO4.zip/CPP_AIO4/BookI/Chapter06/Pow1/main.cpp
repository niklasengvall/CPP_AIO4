#include <iostream>
#include <math.h>

using namespace std;

int main()
{
  double number = 10.0;
  double exponent = 3.0;
  cout << pow(number, exponent) << endl;
  return 0;
}
