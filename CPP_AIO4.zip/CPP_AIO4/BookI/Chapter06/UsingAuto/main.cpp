#include <iostream>
#include <math.h>

using namespace std;

int main()
{
  auto mynumber = fabs(-23.87);
  cout << mynumber << endl;
  return 0;
}
