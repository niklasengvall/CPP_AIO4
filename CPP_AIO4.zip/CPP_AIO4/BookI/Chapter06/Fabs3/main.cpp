#include <iostream>
#include <math.h>

using namespace std;

int main()
{
  double start = -253.895;
  double finish = fabs(start);
  cout << finish << endl;
  return 0;
}
