#include <iostream>
#include <math.h>

using namespace std;

int main()
{
  cout << fabs(-10.5) << endl;
  cout << fabs(10.5) << endl;
  return 0;
}
