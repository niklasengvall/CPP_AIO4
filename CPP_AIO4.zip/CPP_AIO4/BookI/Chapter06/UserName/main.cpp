#include <iostream>

using namespace std;

string Username()
{
  return "Elisha";
}

int main()
{
  cout << Username() << endl;
  return 0;
}
