#include <iostream>

using namespace std;

int main() {
  int LotsONumbers[50];
  int x;
  LotsONumbers = &x;
}
