#include <iostream>

using namespace std;

int main()
{
  const int Permanent[5] = { 1, 2, 3, 4, 5 };
  cout << Permanent[1] << endl;

  // Uncomment this line to see an error.
  //Permanent[2] = 5;
}
