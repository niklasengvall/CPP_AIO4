#include <iostream>

using namespace std;

int main() {
  char buddy = 'A';
  int underneath = (int)buddy;
  cout << underneath << endl;
  return 0;
}
